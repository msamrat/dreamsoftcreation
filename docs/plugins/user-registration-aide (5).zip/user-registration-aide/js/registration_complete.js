jQuery(document).ready( function($) {

	
	var message = $('#message').html();
	if ($('#message') == "Registration complete. Please check your e-mail."){
		($('#message') == "REgistration Completed This is my message!!")
	}
	
});
