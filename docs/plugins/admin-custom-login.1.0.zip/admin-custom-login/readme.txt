=== Admin Custom Login ===
Contributors: weblizar
Donate link: http://www.weblizar.com/
Tags: admin, admin login, admin login page, customize, admin custom login, custom login,  branding, custom login, custom login pro, customization, error, login, login error, logo,  customization, themes, wordpress login, login form, admin login form, wordpress login, plugin, jquery form, jquery,  customization, customizer, custom login plugin, background , sideshow, social form, social connect, social share, facebook, twitter, google plug, linkedin, background slideshow, image, logo, custom logo, wordpress admin login, wp login, wp-login, log in, admin, role, subscriber, captcha, security login, customize wordpress login form, wp login form, login form plugin, ogin page, logo, style log in, style login, themes, custom login page, css , html, form style,       
Requires at least: 3.3
Tested up to: 4.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Customize Your WordPress Admin Login Page

== Description ==

Admin custom login plugin give ability to customize your WordPress admin login page according to you. 

Pugin allows to change background color, background image, background slide show, login form color, login form font size, login form position, add social media icon on form and many more features.

> **Standard Features**
>
> * Add Your Own Custom Logo On Login Form
> * Background Color
> * Background Image
> * Background Image Slide Show
> * Login Form Position
> * Login Form Color
> * Login Form Color Opacity
> * Login Form Font Color
> * Login Form Font Size
> * Login Form Button Color
> * Login Form Button Size
> * Login Form Background
> * Add Social Media Icon On Login Form
> * Social Media Icon Color
> * Social Media Icon Size
> * Interactive Plugin Dashboard

If you have any question contact us at here: [Plugin Support Forum ](http://wordpress.org/support/plugin/admin-custom-login) 

== Installation ==

1. Upload the entire **admin-custom-login** folder to the **/wp-content/plugins/** directory.
2. Activate the plugin through the **Plugins** menu in WordPress admin.
3. Go to the Admin Custom Login plugin menu page.
4. Start customizing your admin login form.

== Screenshots ==

1. Custom Login Page Preview
2. Plugin Settings Panel

== Changelog ==

For more information, see [Weblizar](http://wwww.weblizar.com/)

= Version 1.0 =

* This is first and basic version of slider plugin.


= Docs & Support =

If any support required then post your query in WordPress [Plugin Support Forum ](http://wordpress.org/support/plugin/admin-custom-login)

= We Need Your Support =

It is really hard to continue development and support for this free plugin without contributions from users like you. If you are enjoying using our Admin Cusrom Login plugin and find it useful, then please consider to write your positive [__Feedback__](http://wordpress.org/support/view/plugin-reviews/admin-custom-login). Your feedback will help us to encourage and support the plugin's continued development and better user support.

= Translators =

Please contribute to translate our plugin.  Contact at `lizarweb (at) gmail (dot) com`.

== Frequently Asked Questions ==

Please use WordPress [support forum](http://wordpress.org/support/plugin/admin-custom-login) to ask any query regarding any issue.