=== Responsive Banner Slider ===
Contributors: hpinfosys
Tags: Banner, Slider, Responsive Banner
Donate link: http://hpinfosys.com
Requires at least: 3.0.1
Tested up to: 4.1
Stable tag: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Responsive Banner Slider

== Description ==
Responsive Banner Slider

== Installation ==
1. Upload "responsive-banner-slider" to the "/wp-content/plugins/" directory.
1. Activate the plugin through the "Plugins" menu in WordPress.
1. Place "do_shortcode( '[banner-slider]' );" in your templates.

== Screenshots ==
1. The screenshot description corresponds to screenshot-1.(png|jpg|jpeg|gif).
2. The screenshot description corresponds to screenshot-2.(png|jpg|jpeg|gif).
3. The screenshot description corresponds to screenshot-3.(png|jpg|jpeg|gif).

== Changelog ==
= 1.0 =
* Initial release.
