=== Advanced Login Form ===
Contributors: dipto99
Tags: login-form, custom-style, placeholder, icon, color
Requires at least: 3.1
Tested up to: 4.1
Stable tag: 1.0
License: GPLv2 or later

Advanced Login Form is a more customize wordpress plugin that use for wordpress login page. It also style register and forget password page.

== Description ==

Advanced Login Form is a more customize wordpress plugin that use for wordpress login page. It also style register and forget password page.

Major features in Advanced Login Form include:

* Background Image Change
* Responsive Design
* Font Awesome Icon
* Placeholder Text
* Hide Label Text
* Good UI/UX Design

== Installation ==

Best is to install directly from WordPress. If manual installation is required, please make sure that the plugin files are in a folder named "advanced-login-form" (not two nested folders) in the WordPress plugins folder, usually "wp-content/plugins".

== Changelog ==

= 1.0 =
* Make it 1 January, 2015 (New Year Gift)


== Screenshots ==

1. Login Form Screenshort.
2. Register Form Screenshort.
2. Forget Password Form Screenshort.
