<?php
global $userMeta;

echo $userMeta->proDemoImage( 'settings-registration.png' );