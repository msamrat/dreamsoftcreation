<?php
global $userMeta;

echo $userMeta->proDemoImage( 'settings-redirection.png' );