<?php
global $userMeta;

echo $userMeta->proDemoImage( 'settings-profile.png' );