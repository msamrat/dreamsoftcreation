<?php
global $userMeta;

echo $userMeta->proDemoImage( 'settings-login.png' );