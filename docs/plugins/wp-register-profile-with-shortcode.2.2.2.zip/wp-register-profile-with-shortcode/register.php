<?php
/*
Plugin Name: WP Register Profile
Plugin URI: http://aviplugins.com/
Description: This is a simple registration form in the widget. just install the plugin and add the register widget in the sidebar. Thats it. :)
Version: 2.2.2
Author: avimegladon
Author URI: http://avifoujdar.wordpress.com/
*/

/**
	  |||||   
	<(`0_0`)> 	
	()(afo)()
	  ()-()
**/

include_once dirname( __FILE__ ) . '/settings.php';
include_once dirname( __FILE__ ) . '/register_afo_widget.php';
include_once dirname( __FILE__ ) . '/register_afo_widget_shortcode.php';
