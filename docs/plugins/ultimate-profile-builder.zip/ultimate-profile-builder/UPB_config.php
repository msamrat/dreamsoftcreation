<?php
/*Defines variables for table names*/
global $wpdb;

$upb_cat=$wpdb->prefix."upb_cat";

$upb_option=$wpdb->prefix."upb_option";

$upb_field=$wpdb->prefix."upb_field";

$upb_cat=$wpdb->prefix."upb_cat";

$upb_fields =$wpdb->prefix."upb_fields";

$upb_group =$wpdb->prefix."upb_group";
?>