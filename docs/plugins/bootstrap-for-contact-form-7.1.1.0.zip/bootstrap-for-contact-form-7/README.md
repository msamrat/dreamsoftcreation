Bootstrap for Contact Form 7
============================

This is the Github repository for the WordPress plugin Bootstrap for Contact Form 7. Feel free to browse the code here, but if you want to actually use the plugin, please download it from the [WordPress plugin repository](http://wordpress.org/plugins/bootstrap-for-contact-form-7/).

Contributions and Bugs
----------------------

If you have ideas on how to improve the plugin or if you discover a bug, I would appreciate if you shared them with me, right here on Github. In either case, please open a new issue [here](https://github.com/felixarntz/bootstrap-for-contact-form-7/issues/new)!

Usage Instructions and Support
------------------------------

You are currently browsing the Github repository of Bootstrap for Contact Form 7, made for developers. If instead you need instructions on how to use the plugin or if you have a support request, you may find what you're looking for at the [WordPress plugin repository](http://wordpress.org/plugins/bootstrap-for-contact-form-7/).
