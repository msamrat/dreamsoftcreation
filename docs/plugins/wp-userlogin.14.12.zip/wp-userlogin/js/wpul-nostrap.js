jQuery(document).ready(function($){
    $('ul.wpul_menu li img').css({
        'border-radius':'10px',
        'float':'right',
        'width':'32px',
        'height':'auto'
    });
    $('ul.wpul_menu li #welcome').css({
        'display':'block'
    });
});