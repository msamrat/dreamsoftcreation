<?php
/*
 * this is just to explain PRO features
 */


//echo $proFeatures;
?>

<h2>Get PRO Version for only $35.00</h2>
<ul>
	<li>Min files limit</li>
	<li>Max file upload limit set</li>
	<li>Secure download link</li>
	<li>Admin email notification/alert</li>
	<li>Share file (user can send file in email)</li>
	<li>File meta attachment (Awesome feature)</li>
	<li>File sorting, searching, pagination</li>
	<li>Admin: disable/enable upload/download section</li>
	<li>Admin: Allow users to upload files even not registered (public) or set a public message instead redirecting to login page.</li>
	<li>Access to support forum</li>	
</ul>

<a href="http://www.najeebmedia.com/nmedia-file-uploader-pro/">Buy Now</a>

