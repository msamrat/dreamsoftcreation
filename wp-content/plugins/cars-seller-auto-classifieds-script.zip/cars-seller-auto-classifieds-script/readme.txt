﻿=== Car Seller - Auto Classifieds Script   ===
Contributors: arunkushwaha87 
Tags: Car, Car Seller,Car Dealer, Auto, Auto car,Auto Classifieds Script 
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: 1.1.0
License: Apache License v2.0
License URI: http://www.apache.org/licenses/LICENSE-2.0.html


Car Dealers Auto Classifieds Script plugin is completely designed to build rich features car classifieds websites with ease
== Description ==

<a href="mailto:arunkushwaha87@gmail.com">Please write me for Pro version.</a>
Car Dealers - Auto Classifieds Script plugin that allows you to manage your vehicle. Car Dealers - Auto Classifieds Script is an absolute must for car dealerships or car classified websites. It provides car dealers with an Admin Panel that gives you full control over the content and car listings. I have designed the interfaces to help users use the application with ease and this script is user friendly, fully functional and easy to use.

Feature:-
1. You can accept online Request for information.
2. You can select the currency.
3. you can upload the image slider and other specifications for each car.
4. Admin can control everything from easy-to-use administration panel.


<code>[latest_cars number_of_cars_to_show]

Use this shortcode to show the latest cars

example:
[latest_cars 5]
</code>

Also you can show the list of category on widget position using "Car seller category list widget".



For more feature and support please write me at arunkushwaha87@gmail.com, ping me on skype: arunkushwah87 or visit http://www.supportlive24x7.com

== Installation ==

Here's how to install the plugin:

= Using The WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Search for ‘Car Seller - Auto Classifieds Script’
3. Click 'Install Now'
4. Activate the plugin on the Plugin dashboard

= Uploading in WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Navigate to the 'Upload' area
3. Select `carsellers.zip` from your computer
4. Click 'Install Now'
5. Activate the plugin in the Plugin dashboard


= Using FTP =

1. Download `carsellers.zip`
2. Extract the `carsellers` directory to your computer
3. Upload the `carsellers` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard


<code>[latest_cars number_of_cars_to_show]

Use this shortcode to show the latest cars

example:
[latest_cars 5]
</code>



== Frequently Asked Questions ==
For more feature and support please write me at arunkushwaha87@gmail.com, ping me on skype: arunkushwah87 or visit http://www.supportlive24x7.com


<code>[latest_cars number_of_cars_to_show]

Use this shortcode to show the latest cars

example:
[latest_cars 5]
</code>

Also you can show the list of category on widget position using "Car seller category list widget".


== Screenshots ==
1. `Landing page- Grid view of cars`
2. `Request Form`
3. `Car details page`
4. `Back-end Menu`
5. `Car dealer script's setting page`
6. `Back-end Add & Edit view of cars`
7. `Users' Request List`
8. `Widget - Category Menu `


== Changelog ==