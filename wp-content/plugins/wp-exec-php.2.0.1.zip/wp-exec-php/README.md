WP-exec-PHP
===========

Execute PHP inside posts, pages, text widgets and text widget titles. Add filters and actions using custom feilds.