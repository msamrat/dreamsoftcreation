<div id="wpp-col-right" class="hidden">
		
	<div class="wp-box">
		<div class="inner">
			<h3 class="h2"><?php _e("WordPress Popup Plugin",'wpp'); ?></h3>
		
			<h2><?php _e("Support",'wpp'); ?></h3>
			<p>Please post your question on 
				<a href="http://muneeb.me/support/forum/wp-popup-plugin-2/">
					support forum
				</a>
			</p>
					
			<h2><?php _e("Premium Version",'wpp'); ?></h3>
			<p><?php _e("For more advanced features,extra rules, themes and to get guaranteed support be sure to check out premium version of the plugin.",'wpp'); ?><br />
			<a href="http://muneeb.me/wp-popup-plugin/" target="_blank"><?php _e("Visit the Premium Version website",'wpp'); ?></a></p>
		
			</div>
			<div class="footer footer-blue">
			</div>
	</div>
</div>