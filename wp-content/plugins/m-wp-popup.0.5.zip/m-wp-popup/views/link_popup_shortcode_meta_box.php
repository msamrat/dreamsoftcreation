<input type="text" style="width: 98%;" id="shortcode_text_input" value="<?php echo $shortcode ?>" readonly="true" />
<p class="description" style="margin-top: 25px">
<?php _e( 'To insert a link popup, simply paste the above shortcode in the post or page content editor', 'wpp' ) ?>
</p>