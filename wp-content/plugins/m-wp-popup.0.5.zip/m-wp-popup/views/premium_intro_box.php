<div id="wpp-col-right" class="hidden">
		
	<div class="wp-box">
		<div class="inner">
			<h3 class="h2"><?php _e("WP Popup Plugin",'wpp'); ?></h3>
		
			<h2><?php _e("Support",'wpp'); ?></h3>
			<p>Please post your question on 
				<a href="http://muneeb.me/support/forum/wp-popup-plugin-2/">
					support forum
				</a>
			</p>

				<?php do_action( 'wpp_premium_intro_box' ) ?>
					
			</div>
			<div class="footer footer-blue">
				<ul class="left hl">
					<li><?php _e("Created by",'wpp'); ?> Muneeb ur Rehman</li>
				</ul>
				<ul class="right hl">
					<li><a href="http://twitter.com/tmuneeb"><?php _e("Follow Muneeb",'wpp'); ?></a></li>
				</ul>
			</div>
	</div>
</div>