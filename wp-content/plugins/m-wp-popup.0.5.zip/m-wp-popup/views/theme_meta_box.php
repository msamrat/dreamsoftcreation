<div id="wpp_admin_theme_cont">

    <?php do_action( 'wpp_admin_theme_view', $popup_id ); ?>
 
</div>