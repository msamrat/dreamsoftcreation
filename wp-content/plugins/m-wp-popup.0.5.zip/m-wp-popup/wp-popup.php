<?php
/**
Plugin Name: WP Popup Plugin
Plugin URI: http://rocketplugins.com/wordpress-popup-plugin/?ref=plugin_uri
Description: The best WordPress Popup plugin. Period.
Version: 0.5.23
Author: Muneeb
Author URI: http://rocketplugins.com/wordpress-popup-plugin/?ref=author_uri
License: GPLv2 or later
Copyright: 2015 Muneeb ur Rehman http://rocketplugins.com

http://rocketplugins.com/contact/?ref=plugin_mainfile
**/

require plugin_dir_path( __FILE__ ) . 'config.php';

require POPUP_PLUGIN_INCLUDE_DIRECTORY . 'functions.php';

_load_wpp();