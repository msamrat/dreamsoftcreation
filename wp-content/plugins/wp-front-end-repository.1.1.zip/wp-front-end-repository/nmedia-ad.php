<div class="nm-about-us">


<!-- Nmedia client File Uploader Plugin -->
<div class="box">
<h2>Pro Features</h2>
<p>
<ul style="list-style:inside">
	<li>Admin can upload files for Roles or Public</li>
    <li><strong>multi</strong>: multiple upload</li>	
    <li><strong>file_limit</strong>: control file limits</li>
    <li><strong>file_ext</strong>: restrict file extension</li>
    <li><strong>allow_delete</strong>: switch on/off delete control</li>
    <li><strong>allow_upload</strong>: switch on/ff to upload files</li>
    <li><strong>display_files</strong>: show/hide files</li>
    <li><strong>is_public</strong>: allow all users to see uploaded files</li>
</ul>
<a href="https://docs.google.com/open?id=0B2u2KiDYT-rnZUhfTDJjVG5xdWc">User guide about all shortcodes</a>
</p>
</div>


<!-- Like us -->
<div class="box">
<h2>In LAB</h2>
<h3>Private Conversation System</h3>
<p>
NMedia is busy in developing another great plugin, the Private Conversation System. It is totally ajax based solution to allow your wordpress site users to communicate to each others. It will be launched by next week. If you want to get inform about this please subscribe to following link:<br /><a href="http://eepurl.com/jm1V1">Subscribe to get alert</a>
</p>
</div>



<!-- Like us -->
<div class="box">
<h2>LIKE us?</h2>

<div id="social">
<iframe src="//www.facebook.com/plugins/like.php?href=https://www.facebook.com/pages/Nmedia/191722830857549&amp;send=false&amp;layout=box_count&amp;width=50&amp;show_faces=true&amp;action=like&amp;colorscheme=light&amp;font&amp;height=90&amp;appId=218026514894348" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:90px;text-align:center" allowTransparency="true"></iframe>
</div>
</div>



<!-- About us -->
<div class="box">
<a href="http://www.najeebmedia.com/"><img src="http://www.najeebmedia.com/logo.png" alt="Nmedia Logo" border="0" width="175" /></a>
<h2>About Nmedia</h2>
<p>Nmedia has dedicated itself to serve the Wordpress Community  and You. We just Think, Write and Develop in Wordpress and thus loaded ourselves  with all Wordpress features to develop Plugins, Themes. If you site Need:</p>
<ul style="list-style:inside">
  <li><span dir="LTR"> </span>Cosmetic changes</li>
  <li><span dir="LTR"> </span>Theme integration</li>
  <li><span dir="LTR"> </span>Plugin customization</li>
  <li><span dir="LTR"> </span>Plugin development</li>
  <li><span dir="LTR"> </span>Homepage redesign</li>
  <li><span dir="LTR"> </span>Social/viral Plugins</li>
</ul>
<p><br />
  <br />
  Thanks<br />
  Najeeb Ahmad<br />
  <a href="mailto:ceo@najeebmedia.com">ceo@najeebmedia.com</a>
</p>
</div>
</div>