    <div id="footer">
          <div class="container">
            <p class="text-muted credit"><a href="http://eodepo.com/bootstrap-ultimate" title="Bootstrap 3 theme for Wordpress" target="_blank"><img src="<?php echo get_template_directory_uri() ?>/panel/rsc/img/adm2.png" alt="eoTheme"> Bootstrap Ultimate</a> by Emin &Ouml;zlem - <a href="http://eminozlem.com" title="Emin Özlem-WP / b2 freelancer">eo</a></span>.
             Also see <a href="<?php get_template_directory_uri() ?>/docs/index.php?page=thanks" target="_blank">thanks</a>
</p>
          </div>
    </div>
</div> <!-- #wrap -->